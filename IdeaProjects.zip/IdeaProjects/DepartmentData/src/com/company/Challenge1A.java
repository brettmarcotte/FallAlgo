package com.company;

import java.util.ArrayList;

public class Challenge1A extends Data{

    public static void CompanyInfo(char a, int num) {

        ArrayList<String[][]> departments;

        for (int i = 0; i < num; i++) {

        }

    }

}

//    function companyInfo(a, num) {
//        let b = []
//        for(let i = 0; i < num; i++) {
//            if(a.length < num) {
//                b.push(a[i])
//            } else {
//                b.push(array[i])
//            }
//        }
//        return console.log(b)
//    }
