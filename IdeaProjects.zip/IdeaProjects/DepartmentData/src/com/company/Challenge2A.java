package com.company;

public class Challenge2A {

    public static void EmployeeInfo() {

    }


}





//for(let i = 0; i < employees.length; i++) {
//        employeeId = employees[i][0]
//        employeeName = employees[i][2] + " " + employees[i][3]
//
//        for(let j = 0; j < employeeDepartment.length; j++) {
//        for(let k = 0; k < departments.length; k++) {
//        for(let l = 0; l < employeeSalaries.length; l++) {
//        if(employeeSalaries[l][1] > 60000 && employeeSalaries[l][1].includes(employeeSalaries[l][1]) && employeeId == employeeDepartment[j][0] && employeeDepartment[j][1] == departments[k][0])
//        console.log(employeeName + " works in the " + departments[k][1] + " department and makes " + employeeSalaries[l][1] + " per year. ")
//
//        }
//
//        }
//
//
//        }
//        }