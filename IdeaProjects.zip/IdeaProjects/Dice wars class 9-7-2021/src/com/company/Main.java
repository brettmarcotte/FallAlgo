package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Menu.start();
//        Game game1 = new Game(2, 3,3);

    }
}


//    You are expected to get as far as you can with this challenge. Please make a copy of where we ended off in class so we can continue from that point, and then continue working on this project solo. Work hard and see how far you can get.
//
//        The program should have a main menu where the user can play the game or exit the program
//
//        When the game starts it will ask how many players are playing and how many dice will be thrown.
//        Min players of 2, Max players: 10
//        Min dice: 1,  Max dice: 10
//
//        Then ask how many rounds: min rounds 1, max rounds 10.
//
//        Each player will be asked to enter their name one at a time.
//
//        The game will then start and each player will roll their die/dice.
//        Each player will be receive a message;
//        "Okay ___ it your turn
//        Press Enter to roll your dice
//
//
//        ___ you rolled: 4, 2, 1, 6"
//
//
//        Where the ___ is the players name.
//
//
//        After everyone has rolled the round ends. Each players round score (all the dice values added up) will be added to their overall game total.
//
//        The player/s with the greatest overall total at the end wins.
//        If there is a tie, all players should be considered winners and the end game display message should display all of their names
//
//
//        If one winner:
//        "The winner of the game is ___ with a score of ___. Congratulations ____!"
//
//
//        If more than one winner:
//        "The winners of the game are ___, ___, and ___ with a score of ___. Congratulations players!"
//
//
//        After the game has ended the program should return to the main menu where the user/s is given the choice to play again, or exit the program.




//    Each round plays as follows (assumes 3 players):
//        1. Player 1 rolls all their dice and their score is calculated.
//        2. Player 2 rolls all their dice and their score is calculated.
//        3. Player 3 rolls all their dice and their score is calculated.
//        4. Round ends
//        5. New round begins
//        6. Player 1 rolls all their dice and their score is added to their score from the last round.
//        .
//        .
//        Each round plays as follows (assumes 3 players, 2 rounds):
//        1. Player 1 rolls all their dice and their score is calculated.
//        2. Player 2 rolls all their dice and their score is calculated.
//        3. Player 3 rolls all their dice and their score is calculated.
//        4. Round ends
//        5. New round begins
//        6. Player 1 rolls all their dice and their score is added to their score from the last round.
//        7. Player 2 rolls all their dice and their score is added to their score from the last round.
//        8. Player 2 rolls all their dice and their score is added to their score from the last round.
//        9. Round ends
//        10. Final scores are calculated and compared.
//        11. Winner is declared.
//
