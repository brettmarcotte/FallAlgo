package com.company;

import java.util.Scanner;

public class CLI {

    private static Scanner input = new Scanner(System.in);
    private static Object String;

    public static int getNum(int min, int max) {
        int num;
        while (true)
            try {
                num = Integer.parseInt(input.nextLine());
                if (num > max || num < min) {
                    System.out.println("Enter a number between " + min + "-" + max);
                } else {
                    break;
                }
            } catch (NumberFormatException nfe) {
                System.out.println("Enter a number between " + min + "-" + max);
            }
        return num;
    }

    public static String getStr(String question) {
        System.out.println(question);
        return input.nextLine();
    }


}

//    public void run() {
//        int choice;
//        System.out.println("Please enter the number for your choice and press Enter: ");
//        System.out.print("> ");
//        choice = CLI.readNumber(gameOptions.length - (gameOptions.length - 1), gameOptions.length);
//        System.out.println();
//
//        if (choice != gameOptions.length) {
//            launchGame(choice);
//        } else {
//            System.out.println("Exiting the program...");
//            System.exit(0);
//        }
//    }
//    public String createGreeting() {
//        greeting =
//                (seperator + "\n" +
//                        welcomeMessage + "\n" +
//                        seperator + "\n" + "\n");
//
//        for (String option: gameOptions) {
//            greeting += option + "\n";
//        }
//
//        return greeting;
//    }
