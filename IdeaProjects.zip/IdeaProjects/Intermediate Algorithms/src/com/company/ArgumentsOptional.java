package com.company;

public class ArgumentsOptional {
}
