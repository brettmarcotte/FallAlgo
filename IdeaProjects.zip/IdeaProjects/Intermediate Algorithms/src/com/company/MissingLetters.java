package com.company;

import java.io.OptionalDataException;

public class MissingLetters {
    public static void fearNotLetter(String str) {

        String fearNotString ="ABCEF";

        for (int i = 0; i < str.length(); i++) {

        }
    }


}
