package com.company;

import java.util.Locale;

public class SpinalTapCase {

    public static void SpinalTap() {
        String str = "The_Andy_Griffith_Show";
        String[] strArr = str.split(" ");
            String newStr = "";

        for(int i = 0; i < strArr.length; i++) {
            String newWord = "";
            for(int j = 0; j < strArr[i].length(); j++) {
//                System.out.println(strArr[i].charAt(j));

                if(strArr[i].charAt(j) > 64 && strArr[i].charAt(j) < 97 && j != 0) {
                    newWord += "-";
                }
                newWord += strArr[i].charAt(j);
            }
            System.out.println(newWord);
            if(i < strArr.length - 1) {
                newStr += newWord + "-";
//                System.out.println(strArr[i]);
            } else {
                newStr += newWord;
            }
//            newStr += strArr[i].substring(0, 1) + strArr[i].substring(1) + "-" ;
        }
        System.out.println(newStr.toLowerCase());
    }

}
