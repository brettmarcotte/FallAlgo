package com.company;

public class MakeAPerson {
}
