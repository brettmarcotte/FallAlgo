package com.company;

public class ReverseAString {

    private static String reversedStr;

//    public static void reverseString() {
//        String input = " Career Devs";
//        StringBuilder input1 = new StringBuilder();
//
//        input1.append(input);
//        input1.reverse();
//
//        System.out.println(input1);
//    }


}

//    function reverseString(str) {
//        for (var reversedStr = "", i = str.length - 1; i >= 0; i--) {
//            reversedStr += str[i];
//        }
//        return reversedStr;
//    }
