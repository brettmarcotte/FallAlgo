package com.company;

import java.util.Stack;

public class ChunkyMonkey {


    public static void ChunkyMonkey() {

//    String[] result = new String[]{" "};
//        int[] chunkArrayInGroups = (["a", "b", "c", "d"], 2);
//    for ( int a = 0; a < arr.length; a++) {
//        if (a % size !== size - 1) temp.push(arr[a]);
//        else {
//            temp.push(arr[a]);
//            result.push(temp);
//            temp = new String[]{" "};
//        }
//    }
//    if (temp.length !== 0) result.push(temp);
//    return result;
//    }
}
//chunkArrayInGroups(["a", "b", "c", "d"], 2);
//        Stack<String> Stack = new Stack<String>();
//        int[] arr =
//        Stack.push("A");
//        Stack.push("B");
//        Stack.push("C");
//        Stack.push("D");
//        Stack.push("2");
//        System.out.println(Stack);
//    }
//}

//    function chunkArrayInGroups(arr, size) {
//        let temp = [];
//        let result = [];
//
//        for (let a = 0; a < arr.length; a++) {
//            if (a % size !== size - 1) temp.push(arr[a]);
//            else {
//                temp.push(arr[a]);
//                result.push(temp);
//                temp = [];
//            }
//        }
//
//        if (temp.length !== 0) result.push(temp);
//        return result;
    }