package com.company;

import java.lang.constant.Constable;

public class FindersKeepers {

    public static void findElement() {
        int num = 0;
        int[] arr = new int[]{2, 3, 4, 5};
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] <= arr[0]) {
                System.out.println(" This is the first index" + arr[i]);
            } else if (arr[i] >= arr[0]) {
                System.out.println("This is not the first element");
        }
    }

}
    
//    public static Constable findElement(int arr, int func) {
//        int num = 0;
        //what would replace size? or .length?
        //what would replace arr?
        //does null replace undefined? I just tried it out to see
        //do I need that static boolean below?
//        for(int i = 0; i < arr.size; i++) {
//            num = arr[i];
//            if(func(num)) {
//                return num;
//            }
//        }
//        return null;
//    }
//
//    private static boolean func(int num) {
//    }
}

//function findElement(arr, func) {
//  let num = 0;
//
//  for (let i = 0; i < arr.length; i++) {
//    num = arr[i];
//    if (func(num)) {
//      return num;
//    }
//  }
//
//  return undefined;
//}
