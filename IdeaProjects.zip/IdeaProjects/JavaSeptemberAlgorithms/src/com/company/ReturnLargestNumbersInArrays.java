package com.company;

import java.util.Arrays;

public class ReturnLargestNumbersInArrays {

//    public static void largestOfFour() {
//
//        int[][] arr = {{4, 5, 1, 3}, {13, 27, 18, 26}, {32, 35, 37, 39}, {1000, 1001, 857, 1}};
//
//        int[] results = new int[0];
//
//        for (int i = 0; i < arr.length; i++) {
//
//            int largestNumber = arr[i][0];
//
//            for (int j = 1; j < arr[i].length; j++) {
//                if (arr[i][j] > largestNumber) {
//                    largestNumber = arr[i][j];
//                }
//            }
//            System.out.println(largestNumber);
//        }
//    }





//        function largestOfFour(arr) {
//
//                let results = [];
//        for(let i = 0; i < arr.length; i++) {
//            let largestNumber = arr[i][0];
//            for (let j = 1; j < arr[i].length; j++) {
//                if(arr[i][j] > largestNumber) {
//                    largestNumber = arr[i][j];
//                }
//            }
//            results[i] = largestNumber;
//        }
//
//        return results;
}

