package com.company;

public class FindTheLongestWordInAString {

//    public static int LongestWordLength(String str) {
//
//        String[] words = str.split(" ");
//        int length = 0;
//        String str = "My name is Brett Marcotte";
//
//        for (String word : words) {
//            if (length < word.length()) {
//                length = word.length();
//
//            }
//        }
//        return length;
//    }
}

//    function findLongestWordLength(str) {
//        let words = str.split(' ');
//        let maxLength = 0;
//
//        for (let i = 0; i < words.length; i++) {
//            if (words[i].length > maxLength) {
//                maxLength = words[i].length;
//            }
//        }
//
//        return maxLength;
//    }