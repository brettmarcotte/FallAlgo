package com.company;

public class ConfirmTheEnding {

//    public static void run(String str) {
//
//        System.out.println(str.endsWith("n"));
//
//    }

}

//    function confirmEnding(str, target) {
//
//        return str.slice(str.length - target.length) === target;
//    }
//
//    confirmEnding("He has to give me a new name", "name");
