package com.company;

public class Mutations {

    public static void mutation(int arr) {




    }

//    public static boolean mutation(int arr) {
//
//        int test = arr[1].toLowerCase();
//        int target = arr[0].toLowerCase;
//        for(int i = 0; i < test.size; i++) {
//            if (target.indexOf(test[i]) < 0) return false;
//        }
//        return true;
    }
//mutation(["hello", "hey"]);

//    function mutation(arr) {
//        let test = arr[1].toLowerCase();
//        let target = arr[0].toLowerCase();
//        for (let i = 0; i < test.length; i++) {
//            if (target.indexOf(test[i]) < 0) return false;
//        }
//        return true;
//    }