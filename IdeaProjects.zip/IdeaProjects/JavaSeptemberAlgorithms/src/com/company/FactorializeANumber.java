package com.company;

public class FactorializeANumber {

//    private static int product;
//
//    public static int factorialize(int num) {
//        for (int product = 1; num > 0; num--) {
//            product *= num;
//        }
//        return product;
//    }
}

//    function reverseString(str) {
//        for (var reversedStr = "", i = str.length - 1; i >= 0; i--) {
//            reversedStr += str[i];
//        }
//        return reversedStr;
//    }