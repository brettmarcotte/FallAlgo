package com.company;

public class WhereDoIBelong {

    public static int[] run() {
        int[] arr = new int[] {1, 2, 3};
        double[] a = new double[]{3.5};

        for(double i = 0; i < arr.length; i++) {
            if (a[0] > arr[2]){

            }
        }
        return arr;
    }




//    public static void getIndexToIns(int arr, int num) {
//        arr.sort((a, b) => a - b);
//
//        for (int i = 0; i < arr.size; i++) {
//            if (arr[i] >= num)
//                return i;
//        }
//        return arr.size;
//    }

}
//getIndexToIns([40,60],50);

//    function getIndexToIns(arr, num) {
//        arr.sort((a, b) => a - b);
//
//        for (let i = 0; i < arr.length; i++) {
//            if (arr[i] >= num)
//                return i;
//        }
//
//        return arr.length;
//    }