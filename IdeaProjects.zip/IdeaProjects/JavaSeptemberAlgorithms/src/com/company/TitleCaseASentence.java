package com.company;

public class TitleCaseASentence {

//    private static String val;
//
//    public static void titleCase(String str) {
//
//        String newString = str.toLowerCase();
//
//
//        String[] convertToArray = str.toLowerCase().split(" ");
//
//        String[] tCArray = new String[convertToArray.length];
//        String tCSentence = "";
//        for (int i = 0; i < convertToArray.length; i++) {
////            String tCWord = Character.toString(Character.toUpperCase(convertToArray[i].charAt(0)));
//            tCArray[i] = convertToArray[i].replace(convertToArray[i].charAt(0), Character.toUpperCase(convertToArray[i].charAt(0)));
//            System.out.println(tCArray[i]);
//            tCSentence += tCArray[i] + " ";
//        }
//        System.out.println(tCSentence);


        //JAVASCRIPT SOLUTION
//    int result = convertToArray.map(function(val) {
//        return val.replace(val.charAt(0), val.charAt(0).toUpperCase());
////        }
//        return result.join(" ");
    }

//    private static Object function(String val) {
////    }
//}
//titleCase("I'm a little tea pot")

//String.prototype.replaceAt = function(index, character) {
//        return (
//        this.substr(0, index) + character + this.substr(index + character.length)
//        );
//        };
//
//        function titleCase(str) {
//        var newTitle = str.split(" ");
//        var updatedTitle = [];
//        for (var st in newTitle) {
//        updatedTitle[st] = newTitle[st]
//        .toLowerCase()
//        .replaceAt(0, newTitle[st].charAt(0).toUpperCase());
//        }
//        return updatedTitle.join(" ");
//        }
//
//        titleCase("I'm a little tea pot");