package com.company;

public class TruncateAString {

    public static void run() {
//        String str = "Hi there";
//        int num = 5;
//
//
//            if (str.length() > num) {
//                System.out.println(str.substring((0, num - 3), + "...");
//            } else {
//                System.out.println(str);
//            }
    }


//    public static String truncateString(String str, int num) {
//        //what would replace size?
//        //what would replace slice?
//        if(str.size > num) {
//            return str.slice(0, num) + "...";
//        } else {
//            return str;
//        }
//        truncateString("A-tisket a-tasket a green and yellow basket", 8);
//    }
}
//    function truncateString(str, num) {
//        // Clear out that junk in your trunk
//        if (str.length > num) {
//            return str.slice(0, num) + "...";
//        } else {
//            return str;
//        }
//    }
//    truncateString("A-tisket a-tasket A green and yellow basket", 8);