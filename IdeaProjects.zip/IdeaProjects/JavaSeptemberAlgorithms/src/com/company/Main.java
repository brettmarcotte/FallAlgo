package com.company;

public class Main {

    public static void main(String[] args) {

//        TitleCaseASentence.titleCase("I'm a little tea pot");
//        CelsiusToFahrenheit.convertToF(30);
//        ReturnLargestNumbersInArrays.largestOfFour();
//        ReverseAString.reverseString();
//        FactorializeANumber.factorialize();
//        FindTheLongestWordInAString.LongestWordLength();
//        ConfirmTheEnding.run("Bastian");
            ChunkyMonkey.ChunkyMonkey();
    }
}
