package com.company;

public class FalsyBouncer {

//    public static String[] bouncer(boolean arr) {
//        String[] newArray;
//        newArray = new String[]{""};
//        for(int i = 0; i < arr.length(); i++) {
//            if (arr[i]) newArray.push(arr[i]);
//        }
//        return newArray;
//    }
//    String[] arr = {7, "ate", "", false, 9};
}

//bouncer([7, "ate", "", false, 9]);

//    function bouncer(arr) {
//        let newArray = [];
//        for(let i = 0; i < arr.length; i++) {
//            if(arr[i]) newArray.push(arr[i]);
//        }
//        return newArray;
//    }
//
//    bouncer([7, "ate", "", false, 9]);