package com.company;

public class RepeatAString {

    public static String repeatStringNumTimes(String str, int num) {
        if (num < 1) {
            return "";
        } else {
            return str + repeatStringNumTimes(str, num - 1);
            //is this needed?
//            repeatStringNumTimes("abc", 3);
        }
    }

}

//    function repeatStringNumTimes(str, num) {
//        var accumulatedStr = "";
//
//        while (num > 0) {
//            accumulatedStr += str;
//            num--;
//        }
//
//        return accumulatedStr;
//    }