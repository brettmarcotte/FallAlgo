package com.company;

public class SliceAndSplice {
//    int[] arr1 = {1, 2, 3};
//    int[] arr2 = {4, 5, 6};
//    int n;
//    public static void sAndS() {
//        int[] arr1 = {1, 2, 3};
//        int[] arr2 = {4, 5, 6};
//        int n;
//
//        int end = 1;
//        int start = 3;
//        int[] slice = new int[end - start];
//        for(int i = 0; i < slice.length; i++) {
//            slice[i] = arr1[start + i];
//        }
//        System.out.println(arr1);
//    }
//
//    public void main(String[] args) {
//        int[] arr = {1, 2, 3};
//        int start = 2, end = 3;
//    }
}
//    public static int sAndS(int arr1, int arr2, char n) {
//        int localArray = arr2.slice();
//        for (int i = 0; i < arr1.size; i++) {
//            localArray.splice(n, 0, arr1[i]);
//            n++;
//        }
//        return localArray;
//    }

//}
//frankenSplice({1, 2, 3}, {4, 5, 6}, 1);

//    function frankenSplice(arr1, arr2, n) {
//        let localArray = arr2.slice();
//        for(let i = 0; i < arr1.length; i++) {
//            localArray.splice(n, 0, arr1[i]);
//            n++;
//        }
//        return localArray;
//    }
//
//    frankenSplice([1, 2, 3], [4, 5, 6], 1);