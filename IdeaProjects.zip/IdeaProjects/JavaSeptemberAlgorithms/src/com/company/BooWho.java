package com.company;

public class BooWho {

//    public static boolean booWho(boolean bool) {
//        //what would replace typeof?
//        //what is the issue with the ===?
//        //Uses the operator typeof to check if the variable is a boolean.
//        return typeof bool === "boolean";
//    }
}

//    function booWho(bool) {
//        return typeof bool === "boolean";
//    }
//
//    // test here
//    booWho(null);