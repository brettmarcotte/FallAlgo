package com.company;

public class CelsiusToFahrenheit {

    private static Object celsius;

    public static <celsius> void convertToF(int celsius) {
        int fahrenheit;
        fahrenheit = celsius + 32;
        System.out.println(fahrenheit);
    }

    private static int celsius(int i) {

        return 0;
    }

    public static void convertToF() {
    }
}
